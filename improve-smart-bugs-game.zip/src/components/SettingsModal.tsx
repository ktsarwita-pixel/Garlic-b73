import { useEffect, useState } from "react";
import { IconClose, IconGlobe, IconSettings } from "./CustomIcons";
import { fill, useSettings, type Lang } from "../i18n";
import { playSfx, setSfxEnabled, setSfxVolume, useSfxSettings } from "../game/sfx";
import { clearCareer, useCareer } from "../game/career";
import { isAdvancedGameLocation } from "../game/build-mode";
import type { RenderResolution } from "../game/render-quality";

interface Props {
  open: boolean;
  onClose: () => void;
}

const LANGS: { id: Lang; native: string; latin: string }[] = [
  { id: "en", native: "English", latin: "English" },
  { id: "id", native: "Bahasa Indonesia", latin: "Indonesian" },
];
const RESOLUTIONS: { id: RenderResolution; label: string }[] = [
  { id: "auto", label: "Auto — adaptive" },
  { id: "low", label: "Low — 50%" },
  { id: "medium", label: "Medium — 75%" },
  { id: "high", label: "High — 100%" },
];

// A browser orientation lock belongs to the page, not to one Settings sheet.
// Keep its ownership across menu/game remounts, without persisting a permission
// that must be requested again by a user gesture after a reload.
const sidewaysSession = { locked: false, usedFullscreen: false, ownsFullscreen: false };
type LockableOrientation = ScreenOrientation & { lock?: (orientation: "landscape") => Promise<void> };

/**
 * Options sheet. Mobile-first bottom sheet, centred dialog on desktop.
 * Preferences apply immediately; browser display permissions are session-only.
 */
export function SettingsModal({ open, onClose }: Props) {
  const { lang, setLang, motion, setMotion, potato, setPotato, resolution, setResolution, background, setBackground, t } = useSettings();
  const sfx = useSfxSettings();
  const career = useCareer();
  // Erasing the record takes two taps; closing the sheet disarms it.
  const [confirmErase, setConfirmErase] = useState(false);
  useEffect(() => { if (!open) setConfirmErase(false); }, [open]);
  const [fullscreen, setFullscreen] = useState(() => !!document.fullscreenElement);
  const [fullscreenError, setFullscreenError] = useState(false);
  const [sidewaysLocked, setSidewaysLocked] = useState(() => sidewaysSession.locked);
  const [sidewaysBusy, setSidewaysBusy] = useState(false);
  const [sidewaysMessage, setSidewaysMessage] = useState("");
  const fullscreenSupported = !!document.fullscreenEnabled && !!document.documentElement.requestFullscreen;
  useEffect(() => {
    const sync = () => {
      setFullscreen(!!document.fullscreenElement);
      // Browsers release a fullscreen orientation lock when the user exits
      // fullscreen (including Escape). Don't leave a misleading ON state.
      if (!document.fullscreenElement && sidewaysSession.locked && sidewaysSession.usedFullscreen) {
        try { screen.orientation?.unlock(); } catch { /* already unlocked */ }
        sidewaysSession.locked = sidewaysSession.usedFullscreen = sidewaysSession.ownsFullscreen = false;
        setSidewaysLocked(false);
        setSidewaysMessage("");
      }
    };
    sync();
    document.addEventListener("fullscreenchange", sync);
    return () => document.removeEventListener("fullscreenchange", sync);
  }, []);
  const toggleFullscreen = async () => {
    setFullscreenError(false);
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      setFullscreenError(true);
    }
  };
  const toggleSideways = async () => {
    if (sidewaysBusy) return;
    setSidewaysBusy(true);
    setSidewaysMessage("");
    try {
      if (sidewaysSession.locked) {
        const exitOwnedFullscreen = sidewaysSession.ownsFullscreen && !!document.fullscreenElement;
        try { screen.orientation?.unlock(); } catch { /* fullscreen exit also releases the lock */ }
        sidewaysSession.locked = sidewaysSession.usedFullscreen = sidewaysSession.ownsFullscreen = false;
        setSidewaysLocked(false);
        if (exitOwnedFullscreen) {
          try { await document.exitFullscreen(); } catch { /* user can exit fullscreen separately */ }
        }
        return;
      }
      const orientation = screen.orientation as LockableOrientation | undefined;
      if (typeof orientation?.lock !== "function") {
        setSidewaysMessage("Could not lock orientation. Rotate your device sideways; the layout adjusts automatically.");
        return;
      }
      let ownsFullscreen = false;
      try {
        // Most mobile browsers require fullscreen; installed apps may allow
        // locking without it. Preserve fullscreen if the player entered it.
        if (!document.fullscreenElement && fullscreenSupported) {
          try {
            await document.documentElement.requestFullscreen();
            ownsFullscreen = !!document.fullscreenElement;
          } catch { /* still try: standalone browsers may allow orientation lock */ }
        }
        await orientation.lock("landscape");
        sidewaysSession.locked = true;
        sidewaysSession.usedFullscreen = !!document.fullscreenElement;
        sidewaysSession.ownsFullscreen = ownsFullscreen;
        setSidewaysLocked(true);
        setSidewaysMessage("Sideways orientation is locked. Unlock it to return to your device's normal rotation.");
      } catch {
        if (ownsFullscreen && document.fullscreenElement) {
          try { await document.exitFullscreen(); } catch { /* user can exit fullscreen separately */ }
        }
        setSidewaysMessage("Could not lock orientation. Rotate your device sideways; the layout adjusts automatically.");
      }
    } finally {
      setSidewaysBusy(false);
    }
  };
  const advancedDoctor = isAdvancedGameLocation(window.location);
  const [doctor, setDoctor] = useState(() => {
    try {
      const stored = localStorage.getItem("sb-doctor");
      return stored === "1" || (advancedDoctor && stored !== "0" && new URLSearchParams(location.search).get("doctor") === "1");
    } catch { return advancedDoctor && new URLSearchParams(location.search).get("doctor") === "1"; }
  });
  const setDoctorState = (v: boolean) => {
    setDoctor(v);
    try { localStorage.setItem("sb-doctor", v ? "1" : "0"); } catch { /* storage blocked */ }
    window.dispatchEvent(new CustomEvent("sb-doctor", { detail: v }));
  };
  // Escape closes the sheet — must sit above the early return (hook order).
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;

  return (
    <div
      className="edge-modal-backdrop fixed inset-0 z-[90] flex items-end justify-center bg-black/80 backdrop-blur-[3px] sm:items-center sm:p-4"
      role="presentation"
      onClick={onClose}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-title"
        className="rise flex max-h-[90dvh] w-full max-w-[460px] flex-col overflow-hidden border-2 border-[#4A3828] bg-[#120D09] shadow-[0_18px_60px_rgba(0,0,0,.9)]"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between gap-3 border-b border-[#3B322A] bg-[#1D150F] px-4 py-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-10 w-10 shrink-0 place-items-center border border-[#4A3828] bg-[#17110C] text-[#F0A93B]">
              <IconSettings size={19} />
            </span>
            <div className="min-w-0">
              <h2 id="settings-title" className="font-pixel text-[11px] text-[#FFF3DC]">
                {t("SETTINGS")}
              </h2>
              <p className="latin text-[12px] text-[#9C8F7E]">{t("LANGUAGE & DISPLAY")}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t("CLOSE")}
            className="grid h-11 w-11 shrink-0 place-items-center border border-[#4A3828] bg-[#120D09] text-[#EDE2CB] active:translate-y-[1px]"
          >
            <IconClose size={13} />
          </button>
        </header>

        <div className="safe-b min-h-0 flex-1 overflow-y-auto p-3.5">
          <div className="mb-2 flex items-center gap-2">
            <IconGlobe size={14} className="text-[#56DCA8]" />
            <h3 className="label text-[8px] text-[#56DCA8]">{t("LANGUAGE")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("LANGUAGE")}>
            {LANGS.map((option) => {
              const on = lang === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => setLang(option.id)}
                  className={`lift min-h-[56px] border px-3 py-2 text-left ${
                    on
                      ? "border-[#F0A93B] bg-[#241B14] shadow-[0_0_0_1px_#F0A93B]"
                      : "border-[#3B322A] bg-[#17110C] hover:border-[#6B4B24]"
                  }`}
                >
                  <span className="block font-pixel text-[9px]" style={{ color: on ? "#F0A93B" : "#EDE2CB" }}>
                    {option.native}
                  </span>
                  <span className="mt-1 block font-mono text-[9px] text-[#8C7E6E]">{option.latin}</span>
                  <span className="mt-1 block label text-[6.5px]" style={{ color: on ? "#56DCA8" : "#6B5F52" }}>
                    {on ? t("SELECTED") : ""}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Sound (v0.8) — synthesised on the device, off by one tap */}
          <div className="mt-4 mb-2 flex items-center gap-2">
            <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" className="text-[#F0A93B]">
              <path d="M2 5h2.4L7.5 2.4v9.2L4.4 9H2Z" fill="currentColor" />
              <path d="M9.4 4.6a3.4 3.4 0 0 1 0 4.8M11 3a5.6 5.6 0 0 1 0 8" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
            </svg>
            <h3 className="label text-[8px] text-[#F0A93B]">{t("SOUND")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("SOUND")}>
            {([true, false] as const).map((option) => {
              const on = sfx.enabled === option;
              return (
                <button
                  key={String(option)}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => { setSfxEnabled(option); if (option) playSfx("select"); }}
                  className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${
                    on
                      ? "border-[#F0A93B] bg-[#241B14] text-[#F0A93B] shadow-[0_0_0_1px_#F0A93B]"
                      : "border-[#3B322A] bg-[#17110C] text-[#B3A594] hover:border-[#6B4B24]"
                  }`}
                >
                  {option ? t("On — synthesized effects") : t("Off — silent")}
                </button>
              );
            })}
          </div>
          <label className="mt-2 flex min-h-[44px] items-center gap-3 border border-[#3B322A] bg-[#17110C] px-3" style={{ opacity: sfx.enabled ? 1 : 0.5 }}>
            <span className="label shrink-0 text-[7px] text-[#B3A594]">{t("VOLUME")}</span>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={Math.round(sfx.volume * 100)}
              disabled={!sfx.enabled}
              onChange={(e) => setSfxVolume(Number(e.target.value) / 100)}
              onPointerUp={() => playSfx("buy")}
              onKeyUp={() => playSfx("buy")}
              aria-label={t("VOLUME")}
              className="h-6 min-w-0 flex-1 accent-[#F0A93B]"
            />
            <output className="w-9 shrink-0 text-right font-mono text-[10px] tabular-nums text-[#EDE2CB]">{Math.round(sfx.volume * 100)}%</output>
          </label>
          <p className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">
            {t("All sounds are generated on your device — nothing is downloaded. Sound starts after your first tap.")}
          </p>

          {advancedDoctor && <>
            <div className="mt-4 mb-2 flex items-center gap-2">
              <IconSettings size={13} className="text-[#56DCA8]" />
              <h3 className="label text-[8px] text-[#56DCA8]">{t("SIDEWAYS MODE")}</h3>
            </div>
            <button type="button" onClick={toggleSideways} disabled={sidewaysBusy}
              aria-pressed={sidewaysLocked} aria-describedby="sideways-help"
              className="lift min-h-[48px] w-full border border-[#4A3828] bg-[#17110C] px-3 py-2 text-left font-mono text-[11px] text-[#EDE2CB] hover:border-[#56DCA8] disabled:opacity-50">
              {sidewaysLocked ? t("Unlock sideways orientation") : t("Lock sideways orientation")}
            </button>
            <p id="sideways-help" className="mt-2 text-[10px] leading-snug text-[#9C8F7E]" role="status" aria-live="polite">
              {t(sidewaysMessage || "Turn your device sideways for a wider drawer and a side command panel. Automatic locking depends on your browser.")}
            </p>

            <div className="mt-4 mb-2 flex items-center gap-2">
              <IconSettings size={13} className="text-[#F0A93B]" />
              <h3 className="label text-[8px] text-[#F0A93B]">{t("3D RESOLUTION")}</h3>
            </div>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("3D RESOLUTION")} aria-describedby="resolution-help"
              onKeyDown={(event) => {
                const direction = event.key === "ArrowRight" || event.key === "ArrowDown" ? 1
                  : event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 0;
                if (!direction) return;
                event.preventDefault();
                event.stopPropagation();
                const index = RESOLUTIONS.findIndex((item) => item.id === resolution);
                const next = (index + direction + RESOLUTIONS.length) % RESOLUTIONS.length;
                setResolution(RESOLUTIONS[next].id);
                event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="radio"]')[next]?.focus();
              }}>
              {RESOLUTIONS.map((option) => {
                const on = resolution === option.id;
                return <button key={option.id} type="button" role="radio" aria-checked={on} tabIndex={on ? 0 : -1}
                  onClick={() => setResolution(option.id)}
                  className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${on
                    ? "border-[#56DCA8] bg-[#0F241C] text-[#D6FFEF]"
                    : "border-[#3B322A] bg-[#17110C] text-[#B3A594]"}`}>
                  {t(option.label)}
                </button>;
              })}
            </div>
            <p id="resolution-help" className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">
              {t("Presets scale the capped device resolution for 3D; the interface stays sharp. Auto adapts on the battlefield. Potato mode may lower it further.")}
            </p>
          </>}

          <div className="mt-4 mb-2 flex items-center gap-2">
            <IconSettings size={13} className="text-[#F0A93B]" />
            <h3 className="label text-[8px] text-[#F0A93B]">{t("BACKGROUND")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("BACKGROUND")}>
            {(["dark", "light"] as const).map((option) => (
              <button key={option} type="button" role="radio" aria-checked={background === option}
                onClick={() => setBackground(option)}
                className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${background === option ? "border-[#56DCA8] bg-[#0F241C] text-[#D6FFEF]" : "border-[#3B322A] bg-[#17110C] text-[#B3A594]"}`}>
                <span className={`background-swatch background-swatch--${option}`} aria-hidden="true" />
                {option === "dark" ? t("Dark mode") : t("Light mode")}
              </button>
            ))}
          </div>
          <p className="mt-2 text-[10px] leading-snug text-[#9C8F7E]">{t("A soft gray background; game controls stay dark for readability.")}</p>

          <div className="mt-4 mb-2 flex items-center gap-2">
            <IconSettings size={13} className="text-[#F0A93B]" />
            <h3 className="label text-[8px] text-[#F0A93B]">{t("FULLSCREEN")}</h3>
          </div>
          <button
            type="button"
            onClick={toggleFullscreen}
            disabled={!fullscreenSupported}
            aria-pressed={fullscreen}
            className="lift min-h-[48px] w-full border border-[#4A3828] bg-[#17110C] px-3 py-2 text-left font-mono text-[11px] text-[#EDE2CB] hover:border-[#F0A93B] disabled:cursor-not-allowed disabled:opacity-50"
          >
            {fullscreen ? t("Exit fullscreen") : t("Enter fullscreen")}
          </button>
          <p className="mt-2 text-[10px] leading-snug text-[#9C8F7E]" role={fullscreenError ? "alert" : undefined}>
            {!fullscreenSupported ? t("Fullscreen is not available in this browser or embedded view.") : fullscreenError ? t("Could not change fullscreen mode. Your browser or embedded view may block it.") : t("Fullscreen is controlled by your browser; press Escape to exit.")}
          </p>

          <div className="mt-4 mb-2 flex items-center gap-2">
            <IconSettings size={13} className="text-[#F0A93B]" />
            <h3 className="label text-[8px] text-[#F0A93B]">{t("MOTION")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("MOTION")}>
            {(["full", "reduced"] as const).map((option) => {
              const on = motion === option;
              return (
                <button
                  key={option}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => setMotion(option)}
                  className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${
                    on
                      ? "border-[#56DCA8] bg-[#0F241C] text-[#D6FFEF]"
                      : "border-[#3B322A] bg-[#17110C] text-[#B3A594]"
                  }`}
                >
                  {option === "full" ? t("Full motion") : t("Reduced motion")}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">
            {t("Reduced motion quietens ambient effects and the interface.")}
          </p>

          <div className="mt-4 mb-2 flex items-center gap-2">
            <IconSettings size={13} className="text-[#F0A93B]" />
            <h3 className="label text-[8px] text-[#F0A93B]">{t("POTATO MODE")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("POTATO MODE")}>
            {([true, false] as const).map((option) => {
              const on = potato === option;
              return (
                <button
                  key={String(option)}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => setPotato(option)}
                  className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${
                    on
                      ? "border-[#56DCA8] bg-[#0F241C] text-[#D6FFEF]"
                      : "border-[#3B322A] bg-[#17110C] text-[#B3A594]"
                  }`}
                >
                  {option === true ? t("On — weakest devices") : t("Off — full quality")}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">
            {t("Potato mode turns off shadows and glow, drops the render resolution, and hides fireflies. For weaker phones and laptops.")}
          </p>

          <div className="mt-4 mb-2 flex items-center gap-2">
            <IconSettings size={13} className="text-[#75D9E8]" />
            <h3 className="label text-[8px] text-[#75D9E8]">{t("UI DOCTOR")}</h3>
          </div>
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t("UI DOCTOR")}>
            {([true, false] as const).map((option) => {
              const on = doctor === option;
              return (
                <button
                  key={String(option)}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => setDoctorState(option)}
                  className={`lift min-h-[48px] border px-3 py-2 text-left font-mono text-[10px] ${
                    on
                      ? "border-[#75D9E8] bg-[#0B2A31] text-[#BDF8FF]"
                      : "border-[#3B322A] bg-[#17110C] text-[#B3A594]"
                  }`}
                >
                  {option === true ? t(advancedDoctor ? "On — find UI and visual bugs" : "On — find broken taps") : t("Off — normal play")}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">
            {t(advancedDoctor ? "Scans touch, layout, chest alignment, Spider facing and rendering. Deep Scan watches for flashes, rotation and stalled animation; visual history records brief issues while enabled." : "Overlay that hunts unresponsive UI: tiny tap targets, covered buttons, clipped panels, and dropped frames. Shows an FPS meter and a copyable report.")}
          </p>

          {/* Career record (v0.8) — stored on this device, erasable here */}
          <div className="mt-4 mb-2 flex items-center gap-2">
            <h3 className="label text-[8px] text-[#F0A93B]">{t("CAREER RECORD")}</h3>
          </div>
          <button
            type="button"
            disabled={career.matches === 0}
            onClick={() => {
              if (!confirmErase) return setConfirmErase(true);
              clearCareer();
              setConfirmErase(false);
            }}
            className={`min-h-[46px] w-full border px-3 py-2 text-left font-mono text-[10px] disabled:opacity-50 ${
              confirmErase
                ? "border-[#F05A36] bg-[#2A120C] text-[#FFB29E]"
                : "border-[#3B322A] bg-[#17110C] text-[#B3A594] hover:border-[#6B4B24]"
            }`}
          >
            {career.matches === 0
              ? t("No finished matches yet")
              : confirmErase
                ? t("Tap again to erase the record")
                : fill(t("Erase career record ({n} matches)"), { n: career.matches })}
          </button>
          <p className="mt-2 text-[10px] leading-snug text-[#7B6E5F]">{t("Saved on this device only.")}</p>
        </div>

        <div className="border-t border-[#3B322A] p-3">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[46px] w-full border border-[#4A3828] bg-[#17110C] label text-[9px] text-[#EDE2CB] active:translate-y-[1px]"
          >
            {t("CLOSE")}
          </button>
        </div>
      </section>
    </div>
  );
}
