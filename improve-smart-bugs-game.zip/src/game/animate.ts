import type { VoxModel } from "./voxel";
import type { AirstrikePose } from "./airstrike";
import { sampleSpiderRoar } from "./spider-roar-visual";

/* ── Procedural Articulated Insect Animation Driver ──────────
   Every joint target is resolved once per frame, then eased toward
   its goal — so limbs never stick at a stale angle when a state ends. */

const ease = (cur: number, tgt: number, k: number) => cur + (tgt - cur) * k;

interface Pose {
  torsoX: number; torsoY: number; torsoZ: number; torsoS: number;
  torsoPosY: number; torsoPosZ: number;
  headX: number; headY: number; headZ: number;
  headPosY: number; headPosZ: number;
  laX: number; laY: number; laZ: number;
  raX: number; raY: number; raZ: number;
  legsAX: number; legsBX: number; legsAY: number; legsBY: number;
  crownY: number; rootY: number; rootPosZ: number;
}

export function animateInsectRig(
  m: VoxModel,
  id: string,
  t: number,
  uid: number,
  moving: boolean,
  walkPhase: number,
  lunge: number,
  cast: number,
  flash: number,
  stun: number,
  dead: boolean,
  deadT: number,
  dt: number,
  baseY = 0,
  flightPose?: AirstrikePose,
  roarProgress?: number,
  enhancedRoar = false,
) {
  const p: Pose = {
    torsoX: 0, torsoY: 0, torsoZ: 0, torsoS: 1, torsoPosY: 0, torsoPosZ: 0,
    headX: 0, headY: 0, headZ: 0, headPosY: 0, headPosZ: 0,
    laX: 0, laY: 0, laZ: 0, raX: 0, raY: 0, raZ: 0,
    legsAX: 0, legsBX: 0, legsAY: 0, legsBY: 0,
    crownY: 0, rootY: 0, rootPosZ: 0,
  };

  const ap = lunge;                                  // attack 1 → 0
  const cp = cast > 0 ? Math.min(1, 1 - cast / 0.55) : 0; // skill 0 → 1

  if (dead) {
    /* ── defeat: legs curl, body convulses, then rolls onto its side ──
       The roll is capped and the body is lifted as it rolls, so flanks,
       wing tips and curled legs REST on the tile instead of slicing
       through it (the old 99° roll buried the worm's flank and the
       dragonfly's wing tips half a voxel deep in the floor). */
    // the worm's 0.7 roll swung the front body ring ~2.9 voxels against the
    // stationary head dome (slicing the seam open) — the grub now dies with
    // a tiny settle-tilt inside the seam margin instead
    const rollCap = id === "worm" ? 0.06 : id === "dragonfly" ? 0.55 : 0.9;
    const roll = Math.min(rollCap, deadT * 4.4);
    const spasm = Math.max(0, 1 - deadT * 1.6);
    p.torsoZ = roll;
    p.headZ = roll * 1.15;
    p.legsAX = 0.3 * Math.min(1, deadT * 3) + Math.sin(t * 26) * 0.1 * spasm;
    p.legsBX = 0.3 * Math.min(1, deadT * 3) - Math.sin(t * 26) * 0.1 * spasm;
    // dragonfly: fold wings UP at the back in death (negative laX lifts the
    // +z hind blade; positive swung it DOWN into the abdomen rings — the
    // root cause of every death-frame wing clip)
    // worm: any death arm pitch (0.5 original, 0.1 later) swung the exposed
    // hook tips into the body — the grub's mandibles freeze at rest and the
    // death read is carried by the roll + sink
    p.laX = id === "worm" ? 0 : id === "dragonfly" ? -0.45 : 0.5;
    p.raX = p.laX;
    // wings droop with the body but never fold over the spine — a large
    // wing-local roll compounds with the body roll (~125° total on the
    // dragonfly) and lays the right wing across its own back
    // worm: the death fold swings the jaw hooks through the dome — the grub
    // keeps its mandibles near rest; the dragonfly's wings fold a little
    const wingDeath = id === "dragonfly" ? 0.12 : id === "worm" ? 0 : 0.4;
    p.laZ = -wingDeath;
    p.raZ = wingDeath;
    // worm: the 0.35 death nod drove the dome's lower rim through ring0 —
    // the grub keeps its head inside the sealed socket
    p.headX = id === "worm" ? 0.06 : 0.35;
    if (id === "spider") {
      // the widow dies the classic way: legs curl tight under the body
      p.legsAX = 0.72;
      p.legsBX = 0.72;
      p.laZ = -0.32;
      p.raZ = 0.32;
    }
    p.rootY = -Math.min(0.1, deadT * 0.14) + Math.sin(roll) * (id === "worm" ? 0.75 : 0.3);
    p.torsoS = 1;
  } else {
    /* ── shared life: breathing abdomen + curious head ── */
    const breath = Math.sin(t * 2.6 + uid) * 0.03;
    p.torsoS = 1 + breath;
    p.headY = Math.sin(t * 1.15 + uid * 0.7) * 0.1;
    p.headX = Math.sin(t * 1.7 + uid) * 0.04;

    if (moving) {
      /* ── alternating tripod gait: L1·R2·L3 swing against R1·L2·R3 ── */
      const sw = Math.sin(walkPhase);
      p.legsAX = sw * 0.5;
      p.legsBX = -sw * 0.5;
      p.legsAY = Math.max(0, sw) * 0.028;
      p.legsBY = Math.max(0, -sw) * 0.028;
      p.torsoZ = sw * 0.06;
      p.torsoX = 0.09;                    // forward drive lean
      p.torsoPosY = Math.abs(Math.sin(walkPhase * 2)) * 0.012;
      p.headX = -0.06;                    // counter-balance the lean
    } else {
      /* ── standing: weight settles, tarsi tap ── */
      p.legsAX = Math.sin(t * 1.4 + uid) * 0.03;
      p.legsBX = -Math.sin(t * 1.4 + uid) * 0.03;
      p.torsoX = Math.sin(t * 0.9 + uid) * 0.015;
    }

    /* ── species articulation ── */
    if (id === "stag") {
      // 300 HP of armoured brawler — every bite drives through the whole body,
      // six legs shoving the mandibles into the target.
      if (cp > 0) {
        // Pincer Lock — rear back -> clamp -> thrash the pinned prey
        const wind = Math.min(1, cp / 0.3);
        const bite = cp > 0.3 ? Math.min(1, (cp - 0.3) / 0.18) : 0;
        const shake = cp > 0.48 ? (cp - 0.48) / 0.52 : 0;
        const snap = Math.sin(bite * Math.PI * 0.5); // slams shut and HOLDS
        const rattle = Math.exp(-shake * 2.2) * Math.sin(shake * 42);

        p.torsoX = -wind * 0.22 + snap * 0.3;
        p.torsoPosZ = wind * 0.1 - snap * 0.22;
        p.torsoZ = rattle * 0.12;
        p.headX = -wind * 0.3 + snap * 0.34;
        p.headPosZ = wind * 0.08 - snap * 0.26;
        p.headY = rattle * 0.3;                      // thrashes the prey side to side
        p.laY = wind * 0.85 - snap * 1.0;            // yawn wide, then cross and lock
        p.raY = -p.laY;
        p.legsAX = -wind * 0.3 + snap * 0.5;
        p.legsBX = -wind * 0.3 + snap * 0.5;
        p.rootY = wind * 0.05 - snap * 0.03;
      } else if (ap > 0.01) {
        // Basic bite — coil -> slam -> jolt
        const prog = 1 - ap;
        const open = Math.min(1, prog / 0.28);
        const after = prog > 0.28 ? (prog - 0.28) / 0.72 : 0;
        const snap = after > 0 ? Math.exp(-after * 4.5) : 0;
        const jolt = after > 0 ? Math.exp(-after * 7) * Math.sin(after * 30) : 0;

        p.laY = open * 0.62 - snap * 0.95;           // mandibles cross past each other
        p.raY = -p.laY;
        p.torsoX = -open * 0.12 + snap * 0.26 + jolt * 0.06;
        p.torsoPosZ = open * 0.06 - snap * 0.16;     // coil back, then drive in
        p.headX = -open * 0.14 + snap * 0.26;
        p.headPosZ = open * 0.05 - snap * 0.2;
        p.legsAX = -open * 0.2 + snap * 0.36;        // all six legs shove
        p.legsBX = -open * 0.2 + snap * 0.36;
        p.rootY = -snap * 0.025;
      } else {
        // Idle — slow mandible flexing, like a beetle testing its jaws
        const flex = Math.sin(t * 1.9 + uid) * 0.09;
        p.laY = flex;
        p.raY = -flex;
        p.torsoX = 0.02 + Math.sin(t * 0.9 + uid) * 0.02;
      }
    } else if (id === "bomb") {
      // Artillery beetle. The abdomen is the gun: it cranes up over the back,
      // holds a beat, then slams down as the shell leaves the tail vents.
      // All of it now pivots from the thorax (see torsoPivot), so the body
      // rotates instead of tipping over its feet.
      if (cp > 0) {
        // Caustic Burst — charge -> brace -> fire -> damped settle
        const charge = Math.min(1, cp / 0.32);
        const fire = cp > 0.32 ? Math.min(1, (cp - 0.32) / 0.16) : 0;
        const after = cp > 0.48 ? (cp - 0.48) / 0.52 : 0;
        const kick = after > 0 ? Math.exp(-after * 7) * Math.sin(after * 18) : 0;

        p.torsoX = charge * 0.3 + Math.sin(fire * Math.PI) * 0.34 + kick * 0.1;
        p.torsoPosZ = Math.sin(fire * Math.PI) * 0.13 + kick * 0.05;
        p.torsoPosY = charge * 0.018;
        p.torsoS = 1 + charge * 0.07 - Math.sin(fire * Math.PI) * 0.05;
        p.headX = -charge * 0.12 + Math.sin(fire * Math.PI) * 0.18; // head braces forward
        p.laX = -charge * 0.22 - Math.sin(fire * Math.PI) * 0.4;
        p.raX = p.laX;
        p.laZ = charge * 0.1 + Math.sin(fire * Math.PI) * 0.16;
        p.raZ = -p.laZ;
        p.legsAX = -charge * 0.16 - Math.sin(fire * Math.PI) * 0.2;
        p.legsBX = charge * 0.16 + Math.sin(fire * Math.PI) * 0.2;
        p.rootY = -charge * 0.022 - Math.sin(fire * Math.PI) * 0.03;
      } else if (ap > 0.01) {
        // Single spray — quick aim, sharp kick, clean exponential recovery
        const t0 = 1 - ap;                       // 0 → 1 across the swing
        const aim = Math.min(1, t0 / 0.24);      // snaps to aim in the first quarter
        const shot = t0 > 0.24 ? Math.exp(-(t0 - 0.24) * 6) : 0; // recoil impulse
        const settle = shot * Math.sin((t0 - 0.24) * 26);

        p.torsoX = aim * 0.26 + shot * 0.22 + settle * 0.04;
        p.torsoPosZ = shot * 0.1;
        p.torsoS = 1 + aim * 0.04 - shot * 0.03;
        p.headX = -aim * 0.08 + shot * 0.1;
        p.laX = -aim * 0.2 - shot * 0.35;
        p.raX = p.laX;
        p.laZ = aim * 0.1;
        p.raZ = -p.laZ;
        p.legsAX = -aim * 0.12 - shot * 0.16;
        p.legsBX = aim * 0.12 + shot * 0.16;
        p.rootY = -shot * 0.02;
      } else {
        // Idle — tail rides cocked, antennae hunt out of phase, vents churn
        p.torsoX = 0.05 + Math.sin(t * 1.0 + uid) * 0.03;
        p.torsoS = 1 + Math.sin(t * 3.1 + uid) * 0.045;
        p.torsoZ = Math.sin(t * 0.8 + uid) * 0.018;
        p.laZ = 0.08 + Math.sin(t * 1.4 + uid) * 0.1;
        p.raZ = -0.08 - Math.sin(t * 1.4 + uid + 2.1) * 0.1;
        p.laX = Math.sin(t * 2.0 + uid) * 0.06;
        p.raX = Math.sin(t * 1.8 + uid + 1.4) * 0.06;
      }
    } else if (id === "mantis") {
      if (cp > 0) {
        // Raking Slash — rears tall, both scythes sweep a crossed arc
        const air = Math.sin(cp * Math.PI);
        p.headX = -air * 0.4;
        p.laX = -air * 1.45;
        p.laZ = -air * 0.55;
        p.raX = -air * 1.45;
        p.raZ = air * 0.55;
        p.rootY = air * 0.09;
        p.torsoX = -air * 0.16;
      } else if (ap > 0.01) {
        // Strike — left scythe leads, right follows a beat later
        const cutL = Math.sin(Math.min(1, ap * 1.7) * Math.PI);
        const cutR = Math.sin(Math.max(0, Math.min(1, (ap - 0.22) * 2.1)) * Math.PI);
        p.headX = -ap * 0.3;
        p.laX = -cutL * 1.25;
        p.laY = cutL * 0.4;
        p.raX = -cutR * 1.25;
        p.raY = -cutR * 0.4;
        p.rootY = ap * 0.04;
      } else {
        // Idle — held in prayer, forelegs flexing, head tracking prey
        const pray = Math.sin(t * 1.5 + uid) * 0.11;
        p.laX = pray;
        p.raX = -pray;
        p.headY += Math.sin(t * 0.8 + uid) * 0.14;
      }
    } else if (id === "dragonfly") {
      // A four-winged hover, not a ground run. The fore and hind wing pairs
      // beat slightly out of phase to give the silhouette a recognizable hum.
      const phase = t * 44 + uid * 0.41;
      const hover = Math.abs(Math.sin(phase * 0.5));
      if (flightPose) {
        // World-space flight lives on the holder. Animate the SAME specimen's
        // wings and legs inside it; never substitute a shell or a glow ball.
        const fold = flightPose.wingFold;
        // Odonate stroke: sharper down-stroke via a 2nd harmonic, tilt + twist.
        const beat = phase * 1.5;
        const flap = (1 - fold) * 0.34 * (Math.sin(beat) + 0.42 * Math.sin(beat * 2));
        p.rootY = 0;
        p.torsoX = 0;
        p.torsoY = 0;
        p.torsoZ = 0;
        p.headX = -0.06;
        p.headY = flightPose.phase === "approach" ? Math.sin(t * 7) * 0.18 : 0;
        p.laX = 0.3 + (1 - fold) * 0.1 * Math.sin(beat + 1.2) + fold * 0.1;
        p.raX = 0.3 - (1 - fold) * 0.1 * Math.sin(beat + 1.2) - fold * 0.1;
        // sweep BACK and TILT UP into a V when folding (away from the head);
        // exact mirror pair. A flat back-sweep laid the blades across the
        // spine and through each other — the raised V keeps every cell clear.
        p.laY = 0.12 + fold * 0.3;
        p.raY = -0.12 - fold * 0.3;
        p.laZ = -0.12 + flap - fold * 0.5;
        p.raZ = 0.12 - flap + fold * 0.5;
        p.legsAX = -0.1 - fold * 0.05;
        p.legsBX = -0.1 - fold * 0.05;
        p.legsAY = 0;
        p.legsBY = 0;
      } else if (ap > 0.01) {
        // Needle-fast interception: folded wings, forward dart, braking flare.
        const dart = Math.sin((1 - ap) * Math.PI);
        p.rootY = hover * 0.035 + dart * 0.12;
        p.torsoX = 0.16 + dart * 0.18;
        p.headX = -0.18 + dart * 0.12;
        p.torsoPosZ = -dart * 0.075;
        p.laX = 0.24 + dart * 0.1;
        p.raX = 0.24 - dart * 0.1;
        p.laY = 0.12 + dart * 0.3;
        p.raY = -0.12 - dart * 0.3;
        const flap = 0.26 * (Math.sin(phase) + 0.42 * Math.sin(phase * 2));
        p.laZ = -0.12 + flap - dart * 0.5;
        p.raZ = 0.12 - flap + dart * 0.5;
        p.legsAX = -dart * 0.1;
        p.legsBX = -dart * 0.1;
      } else {
        // Stationary hover: wings hum at speed; the rudder abdomen counter-steers.
        // The two wings are EXACT mirrors (same sine, mirrored sign) — the old
        // phase offsets left them visibly at different angles on the menu
        // turntable, reading as mismatched arrows instead of one beating pair.
        // Odonate kinematics: fast shallow stroke with a sharper down-stroke
        // (2nd harmonic), a tilted stroke plane (constant laX base), and a
        // feathering twist ~90° out of phase — wing tips trace a figure-8,
        // like a real dragonfly, instead of a pendular moth flap.
        const flap = 0.46 * (Math.sin(phase) + 0.38 * Math.sin(phase * 2));
        const twist = 0.11 * Math.sin(phase + 1.2);
        // narrow, BACK-biased yaw: tips never sweep forward over the head
        const sway = Math.sin(phase * 0.5) * 0.1;
        p.rootY = hover * 0.075 + 0.045;
        // body dips a hair against each down-stroke and rolls with the sway —
        // real odonates tilt while hovering, not just the wings
        p.torsoX = 0.03 + Math.sin(t * 2.1 + uid) * 0.035 + flap * 0.05;
        p.torsoZ = Math.sin(phase * 0.5) * 0.03;
        p.torsoY = Math.sin(t * 1.5 + uid) * 0.055;
        p.torsoZ = Math.sin(t * 2.3 + uid) * 0.04;
        p.headX = Math.sin(t * 1.6 + uid) * 0.055;
        p.headY = Math.sin(t * 1.1 + uid) * 0.12;
        // stroke-plane rocks into each down-stroke (relative wind) — visibly
        // "power" flapping, not a gentle hum
        p.laX = 0.2 + twist + flap * 0.12;
        p.raX = 0.2 - twist - flap * 0.12;
        p.laY = 0.1 + sway;
        p.raY = -0.1 - sway;
        p.laZ = -0.18 + flap;
        p.raZ = 0.18 - flap;
        p.legsAX = Math.sin(t * 3 + uid) * 0.06;
        p.legsBX = -Math.sin(t * 3 + uid) * 0.06;
      }
    } else if (id === "spider") {
      // Black widow skitter: the two leg sets rock fast against each other
      // (a scurrying scuttle, no alternating tripods), the body rides low.
      // The bite rears the front half up and STABS both fangs down-forward;
      // the web spit rears higher with the fangs spread wide.
      if (roarProgress !== undefined) {
        if (enhancedRoar) {
          const { rear, release, tremble } = sampleSpiderRoar(roarProgress);
          // Keep the torso rotation fixed during the cast. The head, fangs,
          // legs and pressure waves still carry the roar's expressive pose.
          p.torsoPosY = 0.07 * rear;
          p.headX = -0.43 * rear + tremble * 0.045 + release * 0.09;
          p.headPosY = 0.04 * rear;
          p.laX = p.raX = -0.68 * rear + release * 0.12;
          p.laZ = -0.82 * rear; p.raZ = 0.82 * rear;
          p.legsAX = -0.24 * rear; p.legsBX = 0.24 * rear;
          p.rootY = 0.055 * rear;
        } else {
          const phase = Math.max(0, Math.min(1, roarProgress));
          const swell = Math.sin(Math.PI * phase);
          const tremble = Math.sin(phase * Math.PI * 12) * swell;
          p.torsoX = -0.34 * swell;
          p.torsoPosY = 0.1 * swell;
          p.headX = -0.3 * swell + tremble * 0.07;
          p.laX = p.raX = -0.5 * swell;
          p.laZ = -0.65 * swell; p.raZ = 0.65 * swell;
          p.legsAX = -0.18 * swell; p.legsBX = 0.18 * swell;
          p.rootY = 0.06 * swell;
        }
      } else if (cp > 0) {
        const rear = Math.sin(Math.min(1, cp / 0.75) * Math.PI);
        p.torsoX = -0.2 * rear;
        p.torsoPosY = 0.06 * rear;
        p.headX = -0.14 * rear;
        p.laX = -0.35 * rear;
        p.raX = -0.35 * rear;
        p.laZ = -0.3 - 0.28 * rear; // fangs spread wide, then snap
        p.raZ = 0.3 + 0.28 * rear;
      } else if (ap > 0.01) {
        const stab = Math.sin(ap * Math.PI);
        p.torsoX = 0.06 + 0.14 * stab;
        p.torsoPosZ = 0.1 * stab; // pounce
        p.rootY = 0.03 * stab;
        p.laZ = -0.15 - 0.55 * stab; // fangs swing forward and down
        p.raZ = 0.15 + 0.55 * stab;
        p.laX = 0.12 * stab;
        p.raX = 0.12 * stab;
      } else if (moving) {
        const skitter = Math.sin(walkPhase * 1.8);
        p.legsAX = skitter * 0.42;
        p.legsBX = -skitter * 0.42;
        p.legsAY = Math.max(0, skitter) * 0.03;
        p.legsBY = Math.max(0, -skitter) * 0.03;
        p.torsoZ = skitter * 0.05;
        p.torsoX = 0.1;
        p.headX = -0.05;
      } else {
        // idle: pedipalp feelers taste the air, legs tap
        p.laZ = -0.08 + Math.sin(t * 5.2 + uid) * 0.07;
        p.raZ = 0.08 - Math.sin(t * 5.2 + uid) * 0.07;
        p.legsAX = Math.sin(t * 3.1 + uid) * 0.05;
        p.legsBX = -Math.sin(t * 3.1 + uid) * 0.05;
      }
    } else if (id === "matriarch") {
      // Royal levitation — the whole body rides a slow hover, crown bobbing apart
      const lev = Math.sin(t * 1.9 + uid) * 0.045;
      p.rootY = lev + 0.05;
      p.crownY = Math.sin(t * 2.7 + uid) * 0.018 + 0.02;
      p.torsoS = 1 + Math.sin(t * 2.2 + uid) * 0.045;   // brood pulse
      p.headY = Math.sin(t * 0.7 + uid) * 0.16;
      p.laZ = Math.sin(t * 1.3 + uid) * 0.07;
      p.raZ = -Math.sin(t * 1.3 + uid) * 0.07;
      if (cp > 0) {
        const hymn = Math.sin(cp * Math.PI);
        p.crownY += hymn * 0.1;
        p.torsoS += hymn * 0.07;
      }
    } else if (id === "worm") {
      // A low armored grub: peristaltic body pulse, the shovel head lifting
      // and dropping as it bulldozes, hooked mandibles snipping in exact
      // mirror, flank setae rippling.
      const snip = Math.sin(t * 2.6 + uid);
      p.torsoY = Math.sin(t * 1.15 + uid) * 0.04;
      p.torsoZ = Math.sin(t * 0.8 + uid * 1.3) * 0.03;
      p.torsoX = Math.sin(t * 1.3 + uid) * 0.03;
      p.torsoS = 1 + Math.sin(t * 1.9 + uid) * 0.05; // peristalsis
      p.rootY = Math.sin(t * 1.5 + uid) * 0.015 + 0.008;
      // +0.02 bias keeps the shovel chin above the floor at the low end
      // (the old symmetric +-0.1 dug the front face ~0.2 voxel deep)
      p.headX = 0.02 + Math.sin(t * 1.2 + uid) * 0.06; // bulldozing lift
      p.headY = Math.sin(t * 0.9 + uid) * 0.05;
      // Mandibles snip by flaring OUTWARD from authored rest (positive laZ /
      // negative raZ = outward). Zero rest offset is load-bearing: the hook
      // chains sit face-adjacent to the dome flank, so ANY inward phase
      // grinds them (the old snip drove a tip 0.32 vox through it).
      p.laZ = Math.max(0, snip) * 0.2;
      p.raZ = -Math.max(0, snip) * 0.2;
      // a worm has no walking legs — its flank setae only ripple, never swing
      p.legsAX = Math.sin(t * 3.1 + uid) * 0.05;
      p.legsBX = -Math.sin(t * 3.1 + uid) * 0.05;
      p.legsAY = 0;
      p.legsBY = 0;
      if (cp > 0) {
        const rear = Math.sin(cp * Math.PI);
        // worm: the seam cells are face-adjacent — ANY rear pitch slides the
        // dome rim onto ring0 (0.6 vox). The hiss reads through the jaw gape
        // + whole-model lurch instead, both seam-safe.
        p.headX = id === "worm" ? 0 : rear * 0.26; // rears to strike
        p.rootPosZ = -rear * 0.05; // whole-model lurch (torsoPosZ slid the
        // body forward under the stationary head, ramming ring0 into the dome)
        // gape OUTWARD from authored rest (positive laZ = left hook out;
        // any negative/inward base ground the chain into the dome flank)
        p.laZ = rear * 0.45;
        p.raZ = -rear * 0.45;
      } else if (ap > 0.01) {
        // rear up, then chomp the shovel down
        const prog = 1 - ap;
        const wind = Math.min(1, prog / 0.35);
        const slam = prog > 0.35 ? Math.exp(-(prog - 0.35) * 6) : 0;
        // worm: even the capped pitch slides the dome rim onto ring0's
        // corner (0.6 vox) — the grub chomps with jaws + lunge only
        p.headX = id === "worm" ? 0 : wind * 0.18 + slam * 0.06;
        p.rootPosZ = -wind * 0.04 + slam * (id === "worm" ? 0.13 : 0.09); // whole-model lunge
        // gape out, then the chomp closes back TO rest — never past it
        // (the hooks have zero inward clearance against the dome flank)
        p.laZ = wind * 0.45 * (1 - slam);
        p.raZ = -wind * 0.45 * (1 - slam);
        p.rootY = wind * 0.02 - slam * 0.015;
      }
        } else {
      // lampyris — wing covers part and flutter, lantern swells
      const flutter = cp > 0 || ap > 0.1;
      if (flutter) {
        const beat = Math.sin(t * 36) * 0.22;
        p.laY = -0.68 + beat;
        p.raY = 0.68 - beat;
        p.laZ = beat * 0.5;
        p.raZ = -beat * 0.5;
        p.rootY = 0.05 + Math.abs(Math.sin(t * 18)) * 0.02;
      } else {
        const breatheWing = Math.sin(t * 2.3 + uid) * 0.1;
        p.laY = -0.16 + breatheWing;
        p.raY = 0.16 - breatheWing;
        p.rootY = Math.sin(t * 1.7 + uid) * 0.022 + 0.02;
      }
      p.torsoS = 1 + Math.sin(t * 3.1 + uid) * 0.055;    // lantern swelling
    }

    /* ── stun overrides the head with a dizzy roll ── */
    if (stun > 0) {
      const dizzy = Math.sin(t * 8.5);
      if (id === "worm") {
        // the dome sits in a sealed neck socket — yaw-swinging it 0.38 rad
        // ground the rim across ring0's surface (visible noclip). A stunned
        // grub wobbles as a whole and the head stays inside the seal.
        p.headY = dizzy * 0.05;
        p.headZ = 0;
        // no torso roll here: with the idle head bob it closed the diagonal
        // gap between the jaw chains and ring0's neck corner (0.08 vox)
        p.torsoZ = 0;
        p.rootY = Math.cos(t * 6) * 0.012;
        // stunned mandibles buzz OUTWARD from authored rest — same rule as
        // the idle snip: the hook chains have zero inward clearance
        p.laZ = Math.max(0, Math.sin(t * 22)) * 0.2;
        p.raZ = -Math.max(0, Math.sin(t * 22)) * 0.2;
      } else {
        p.headY = dizzy * 0.38;
        p.headZ = Math.cos(t * 8.5) * 0.22;
        p.laZ = Math.sin(t * 22) * 0.14;
        p.raZ = -Math.sin(t * 22) * 0.14;
        p.torsoZ = Math.sin(t * 6) * 0.06;
      }
    }

    /* ── struck: head snaps back along the body ── */
    if (flash > 0) {
      p.headPosZ += flash * 0.16;
      // capped so the worm's shovel nose cannot pitch below the tile top.
      // worm: the sealed neck has ZERO pitch budget — the flinch is the
      // whole-model rootY dip only (headPosZ is zeroed below as well).
      p.headX -= (id === "worm" ? 0 : flash) * 0.15;
      // the worm flinches as a WHOLE model (rootY bump) — any torso pitch or
      // head back-slide swings the front ring / dome rear through the seam
      // (head and torso are sibling groups; nothing carries the seam along)
      if (id !== "worm") {
        p.torsoX -= flash * 0.18;
      } else {
        p.headPosZ = 0;
        p.rootY -= flash * 0.035;
      }
    }
  }

  /* ── resolve: ease every joint toward its target ── */
  const R = m.rest;
  const kLeg = 1 - Math.exp(-dt * 34);   // gait must stay crisp
  const kFast = 1 - Math.exp(-dt * 26);  // strikes
  const kBody = 1 - Math.exp(-dt * 15);  // weight & breath

  // Do not pitch, yaw or roll the Spider's body while Battle Roar is active,
  // even when hit, moving, or retargeting. Resume normal easing afterward.
  if (!(enhancedRoar && id === "spider" && roarProgress !== undefined && !dead)) {
    m.torso.rotation.x = ease(m.torso.rotation.x, p.torsoX, kBody);
    m.torso.rotation.y = ease(m.torso.rotation.y, p.torsoY, kBody);
    m.torso.rotation.z = ease(m.torso.rotation.z, p.torsoZ, kBody);
  }
  const s = ease(m.torso.scale.z, p.torsoS, kBody);
  m.torso.scale.set(1 + (s - 1) * 0.55, 1 + (s - 1) * 0.55, s);
  m.torso.position.y = R.torso.y + ease(m.torso.position.y - R.torso.y, p.torsoPosY, kBody);
  m.torso.position.z = R.torso.z + ease(m.torso.position.z - R.torso.z, p.torsoPosZ, kFast);

  m.head.rotation.x = ease(m.head.rotation.x, p.headX, kFast);
  // The head stays aligned with the opposing side rather than idly swaying.
  m.head.rotation.y = enhancedRoar && id === "spider" && roarProgress !== undefined && !dead
    ? 0 : ease(m.head.rotation.y, p.headY, kBody);
  m.head.rotation.z = ease(m.head.rotation.z, p.headZ, kFast);
  m.head.position.y = R.head.y + ease(m.head.position.y - R.head.y, p.headPosY, kBody);
  m.head.position.z = R.head.z + ease(m.head.position.z - R.head.z, p.headPosZ, kFast);

  m.leftArm.rotation.x = ease(m.leftArm.rotation.x, p.laX, kFast);
  m.leftArm.rotation.y = ease(m.leftArm.rotation.y, p.laY, kFast);
  m.leftArm.rotation.z = ease(m.leftArm.rotation.z, p.laZ, kFast);
  m.rightArm.rotation.x = ease(m.rightArm.rotation.x, p.raX, kFast);
  m.rightArm.rotation.y = ease(m.rightArm.rotation.y, p.raY, kFast);
  m.rightArm.rotation.z = ease(m.rightArm.rotation.z, p.raZ, kFast);

  m.legsA.rotation.x = ease(m.legsA.rotation.x, p.legsAX, kLeg);
  m.legsB.rotation.x = ease(m.legsB.rotation.x, p.legsBX, kLeg);
  m.legsA.position.y = R.legsA.y + ease(m.legsA.position.y - R.legsA.y, p.legsAY, kLeg);
  m.legsB.position.y = R.legsB.y + ease(m.legsB.position.y - R.legsB.y, p.legsBY, kLeg);

  m.crown.position.y = R.crown.y + ease(m.crown.position.y - R.crown.y, p.crownY, kBody);
  m.group.position.y = flightPose ? baseY : ease(m.group.position.y, baseY + p.rootY, kBody);
  m.group.position.z = ease(m.group.position.z, p.rootPosZ, kBody);
}
